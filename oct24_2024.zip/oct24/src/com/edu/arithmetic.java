package com.edu;

public class arithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 100;
		int b=10;
		int sum,sub, mul, div, rem;
		System.out.println("sum="+(a+b));
		System.out.println("sub="+(a-b));
		System.out.println("mul="+(a*b));
		System.out.println("div="+(a/b));
		System.out.println("rem="+(a%b));

	}

}

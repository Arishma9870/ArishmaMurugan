package com.edu;

public class AreaofTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=5, h=2;
		
		System.out.println("Area of a Triangle A="+((b*h)/2));

	}

}

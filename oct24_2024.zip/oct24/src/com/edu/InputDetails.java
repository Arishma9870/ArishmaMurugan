package com.edu;

import java.util.Scanner;

public class InputDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name;
		int age;
		float salary;
		char gen;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter name");
		name = scanner.nextLine();
		
		System.out.println("Enter age");
		age = scanner.nextInt();
		
		System.out.println("Enter salary");
		salary = scanner.nextFloat();
		
		System.out.println("Enter Generation");
		gen = scanner.next().charAt(0);

	}

}

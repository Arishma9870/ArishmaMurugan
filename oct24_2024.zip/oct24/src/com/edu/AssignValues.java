package com.edu;

public class AssignValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 98;
		float f  =98.2f;
		char ch = 'A';
		String s = "Hello";
		double d = 98.3;
		short sh = 70;
		byte b = 24;
		
		System.out.println("Integer="+i);
		System.out.println("Float="+f);
		System.out.println("Chara="+ch);
		System.out.println("String="+s);
		System.out.println("Double="+d);
		System.out.println("Short="+sh);
		System.out.println("Byte="+b);

	}

}

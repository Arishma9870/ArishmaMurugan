package com.edu;

public class AreaofCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r =50;
		
		System.out.println("Area of a Circle A=" +(3.14*r*r));

	}

}

package com.edu;

public class AreaofRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float l =19.5f;
		int b = 21;
		
		System.out.println("Area of Rectangle A =" +(l*b));
		
		

	}

}

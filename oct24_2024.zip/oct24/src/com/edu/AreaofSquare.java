package com.edu;

public class AreaofSquare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		
		System.out.println("Area of a Square A is "+(a*a));

	}

}

package com.edu;

public class Mydeails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("My Name is Arishma");
		System.out.println("Studying in Edubridge");
		System.out.println("Java Fulstack");

	}

}
